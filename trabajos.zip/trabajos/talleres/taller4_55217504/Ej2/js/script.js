//Definicion de objetos
// Create an object:
console.log("Crear y definir objeto")
console.log("Ejemplo 1")
var persona = {//Crea y define el objeto
	//Los valores que tendra el objeto
	nom:"John",
	apellido:"Doe", 
	edad:50, 
	colorOjos:"blue"
};
console.log(persona.nom + " tiene " + persona.edad +" años.");

console.log("Ejemplo 2");
var carro = {
	 model:"aveo",	
	 año:"2012",
}
console.log(carro.model +" es del año "+carro.año);	
console.log("Ejemplo 3");
var animales= {
	nom:"lobo",
	numPatas:"4",
}
console.log("El "+animales.nom+" tiene "+animales.numPatas+" patas.")
