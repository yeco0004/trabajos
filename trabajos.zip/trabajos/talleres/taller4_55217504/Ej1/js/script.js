/* Escribir el código de una función a la que se pasa como 
parámetro un número entero y devuelve como resultado una 
cadena de texto que indica si el número es par o impar. */
console.log("Ejemplo 1")
var num= prompt('digite un número entero'); //pedimos el numero entero al usuario
var resultado=parImpar(num); //llamamos la funcion 
console.log("El numero "+num+" es "+resultado); //damos la cadena que se mostrara

function parImpar(numero){ //creamos la funcion
	if(numero % 2==0){ //usamos el condicional if para definir el numero como par o impar
		return "Par";
	}else{
		return "Impar";
	}

}

/*
Definir una función que muestre información sobre una cadena de texto que se le pasa como argumento. 
A partir de la cadena que se le pasa,
la función determina si esa cadena está formada sólo por mayúsculas,
 sólo por minúsculas o por una mezcla de ambas.
*/
console.log("Ejemplo 2")

function info(cadena){
	var resultado= "La cadena \""+cadena+"\" ";
	 // Comprobar mayúsculas y minúsculas
     if(cadena == cadena.toUpperCase()) {
        resultado += " está formada sólo por mayúsculas";
    }else if(cadena == cadena.toLowerCase()) {
        resultado += " está formada sólo por minúsculas";
    }else {
        resultado += " está formada por mayúsculas y minúsculas";
    }

  return resultado;
}
console.log(info("OVNI = OBJETO VOLADOR NO IDENTIFICADO"));
console.log(info("En un lugar de la mancha..."));

/*
Definir una función que determine si la cadena de texto que se le pasa como parámetro es un palíndromo,
 es decir, si se lee de la misma forma desde la izquierda y desde la derecha. 
 Ejemplo de palíndromo complejo: "La ruta nos aporto otro paso natural".
*/
console.log("Ejemplo 3")

function palindromo(cadena){
	var resultado = "La cadena \""+cadena+"\" \n";

  // Pasar a minusculas la cadena
  var cadenaOriginal = cadena.toLowerCase();

  // Convertir la cadena en un array
  var letrasEspacios = cadenaOriginal.split("");

    // Eliminar los espacios en blanco (este paso es demasiado largo ya que no se utiliza la funcion "replace")
  var cadenaSinEspacios = "";
  for(i in letrasEspacios) {
    if(letrasEspacios[i] != " ") {
      cadenaSinEspacios += letrasEspacios[i];
    }
  }

  
  var letras = cadenaSinEspacios.split("");
  var letrasReves = cadenaSinEspacios.split("").reverse();

  // Este paso tambien es muy largo porque no se utiliza la sentencia "break"
  var iguales = true;
  for(i in letras) {
    if(letras[i] == letrasReves[i]) {
      // Todo bien
    }
    else {
      // Alguna letra es distinta, por lo que ya no es un palindromo
      iguales = false;
    }
  }

  if(iguales) {
    resultado += " es un palíndromo";
  }
  else {
    resultado += " no es un palíndromo";
  }

  return resultado;
}

console.log(palindromo("La ruta nos aporto otro paso natural"));
console.log(palindromo("Esta frase no se parece a ningun palindromo"));
	

